<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20220908235009 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE activation_post_paye_grcs (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, compte_grcs_id INTEGER NOT NULL, date_debut DATETIME NOT NULL, date_fin DATETIME NOT NULL, nombre_jour VARCHAR(255) NOT NULL --(DC2Type:dateinterval)
        , is_cloture BOOLEAN NOT NULL, quantite_max_diesel_autorise INTEGER NOT NULL, quantite_max_essence_autorise INTEGER NOT NULL, CONSTRAINT FK_D64C9F9A13E82344 FOREIGN KEY (compte_grcs_id) REFERENCES ess_compte_grcs (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('CREATE INDEX IDX_D64C9F9A13E82344 ON activation_post_paye_grcs (compte_grcs_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE activation_post_paye_grcs');
    }
}

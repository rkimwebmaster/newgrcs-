<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20220908235331 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE ess_user ADD COLUMN photo VARCHAR(255) DEFAULT NULL');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TEMPORARY TABLE __temp__ess_user AS SELECT id, grcs_id, grand_fournisseur_id, petit_client_id, email, roles, password FROM "ess_user"');
        $this->addSql('DROP TABLE "ess_user"');
        $this->addSql('CREATE TABLE "ess_user" (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, grcs_id INTEGER DEFAULT NULL, grand_fournisseur_id INTEGER DEFAULT NULL, petit_client_id INTEGER DEFAULT NULL, email VARCHAR(180) NOT NULL, roles CLOB NOT NULL --(DC2Type:json)
        , password VARCHAR(255) NOT NULL, CONSTRAINT FK_BB8B9520AB8F1F12 FOREIGN KEY (grcs_id) REFERENCES ess_grcs (id) NOT DEFERRABLE INITIALLY IMMEDIATE, CONSTRAINT FK_BB8B9520766151FA FOREIGN KEY (grand_fournisseur_id) REFERENCES ess_grand_fournisseur (id) NOT DEFERRABLE INITIALLY IMMEDIATE, CONSTRAINT FK_BB8B9520EF41F9BF FOREIGN KEY (petit_client_id) REFERENCES ess_petit_client (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO "ess_user" (id, grcs_id, grand_fournisseur_id, petit_client_id, email, roles, password) SELECT id, grcs_id, grand_fournisseur_id, petit_client_id, email, roles, password FROM __temp__ess_user');
        $this->addSql('DROP TABLE __temp__ess_user');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_BB8B9520E7927C74 ON "ess_user" (email)');
        $this->addSql('CREATE INDEX IDX_BB8B9520AB8F1F12 ON "ess_user" (grcs_id)');
        $this->addSql('CREATE INDEX IDX_BB8B9520766151FA ON "ess_user" (grand_fournisseur_id)');
        $this->addSql('CREATE INDEX IDX_BB8B9520EF41F9BF ON "ess_user" (petit_client_id)');
    }
}
